// Smooth page transition
window.onload = function () {
    document.body.style.opacity = 1;
};